#include <string>

int combine(int, int);
//string combine(int, int);

std::string combine(const std::string&, const std::string&);

std::string combine(const std::string&, int);